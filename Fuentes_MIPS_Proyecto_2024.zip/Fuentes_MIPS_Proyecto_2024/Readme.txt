S�lo hay que modificar los fuentes que incluyen la palabra "completar" y las memorias de datos e instrucciones
Las zonas a completar est�n indicadas con la etiqueta:
-- Completar:

Si quer�is realizar cualquier otro cambio deb�is consultarlo con los profesores

Las partes que han cambiado, con respecto al MIPS de pr�cticas, est�n marcadas y comentadas con la etuqueta.
-- Nuevo: 

El c�digo en la MI est� explicado en la propia MI. Debe sumar las palabras 0 y 1 de memoria y guardarlas en la 2. Despu�s se queda en un bucle infinito.
Para que funcione bien hay que gestionar los riesgos estructurales, parando el MIPS entero cuando la etapa MEM no est� preparada.